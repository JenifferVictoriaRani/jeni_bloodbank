﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using requirement.Models;

namespace requirement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class requirementDisplayController : ControllerBase
    {
        bloodbankContext bb = new bloodbankContext();

        // GET: api/searchAvailability
        [HttpGet]
        public IEnumerable<BloodDetails> Get()
        {
            return bb.BloodDetails.FromSql("requirement").ToList();
        }
        // POST api/values
        [HttpPost("{UserId}")]
        public void Post(int UserId, [FromBody] BloodDetails value)
        {
            bb.Database.ExecuteSqlCommand("reqPost " + UserId + ",'" + value.BloodGroup + "','" + value.State + "','" + value.Area + "'," + value.PinCode + "," + value.Contact);
                
        }
    }
}