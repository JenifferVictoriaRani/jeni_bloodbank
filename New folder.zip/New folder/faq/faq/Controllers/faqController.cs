﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using faq.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace faq.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class faqController : ControllerBase
    {
        bloodbankContext bb = new bloodbankContext();
        // GET: api/faq
        [HttpGet(Name = "Get")]
        public IEnumerable<Faq> Get()
        {
            return bb.Faq.FromSql("selectFaq").ToList();
        }

        // GET: api/faq/5
        //[HttpGet(Name = "GetQues")]
        //public IEnumerable<Faq> Get()
        //{
        //    return bb.Faq.FromSql("dispQues").ToList();
        //}

        // POST: api/faq
        [HttpPost("{id}/{value}")]
        public void Post(int id,string value)
        {
            bb.Database.ExecuteSqlCommand("ques " + id + ",'" + value + "'");
        }

        // PUT: api/faq/5
       

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
