﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using faq.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace faq.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class adminFaqController : ControllerBase
    {
        bloodbankContext bb = new bloodbankContext();
        [HttpGet(Name = "GetQues")]
        public IEnumerable<Faq> Get()
        {
            return bb.Faq.FromSql("dispQues").ToList();
        }

        [HttpPut("{id}/{value}")]
        public void Put(int id, string value)
        {
            bb.Database.ExecuteSqlCommand("quesAns " + id + ",'" + value + "'");
        }
    }
}