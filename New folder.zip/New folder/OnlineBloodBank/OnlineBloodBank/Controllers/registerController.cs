﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineBloodBank.Models;

namespace OnlineBloodBank.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class registerController : ControllerBase
    {
        bloodbankContext bb = new bloodbankContext();
        [HttpGet]
        public UserDetails Get()
        {
            return bb.UserDetails.FromSql("fetchId").Single();
        }

        // POST: api/login
        [HttpPost]
        public void Post([FromBody] UserDetails value)
        {
            bb.Database.ExecuteSqlCommand("registration '" + value.FirstName + "','" + value.LastName + "'," + value.Age + ",'" + value.Gender + "','" + value.Email + "'," + value.Contact + ",'" + value.Pass + "'," + value.Weight + ",'" + value.State + "','" + value.Area + "'," + value.PinCode + ",'" + value.BloodGroup + "'");
        }

    }
}