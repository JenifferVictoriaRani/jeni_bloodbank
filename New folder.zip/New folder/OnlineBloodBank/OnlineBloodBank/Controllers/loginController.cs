﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineBloodBank.Models;
using Microsoft.EntityFrameworkCore;

namespace OnlineBloodBank.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class loginController : ControllerBase
    {
        bloodbankContext bb = new bloodbankContext();

        // GET: api/login
        [HttpGet]
        public IEnumerable<UserDetails> Get()
        {
            return bb.UserDetails.ToList();
        }

        [HttpGet]
        [Route("GetEmails")]
        public IEnumerable<string> GetEmails()
        {
            List<UserDetails> list = bb.UserDetails.ToList();
            List<string> emails = new List<string>();
            foreach (UserDetails user in list)
            {
                emails.Add(user.Email);
            }
            return emails;
        }

        [HttpGet]
        [Route("GetContact")]
        public IEnumerable<long> GetContact()
        {
            List<UserDetails> list = bb.UserDetails.ToList();
            List<long> contact = new List<long>();
            foreach (UserDetails user in list)
            {
                contact.Add(user.Contact);
            }
            return contact;
        }




        // GET: api/login/5
        [HttpGet("{UserId}/{pass}", Name = "Login")]
        public UserDetails Get(int UserId,string Pass)
        {
            try
            {

                return bb.UserDetails.FromSql("loginuser " + UserId + ",'" + Pass + "'").Single();
            }
            catch(Exception e)
            {
                return null;
            }
            

        }
        //[HttpGet]
        //public IEnumerable<UserIdVM> Get([FromBody] UserDetails value)
        //{
        // return bb.UserIdVM.FromSql("dispId '" + value.Email + "','" + value.Pass).ToList();
            
        //}
        
       
        // PUT: api/login/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
