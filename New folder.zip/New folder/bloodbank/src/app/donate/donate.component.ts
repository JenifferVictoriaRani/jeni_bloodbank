import { Component, OnInit } from '@angular/core';
import { BloodService } from '../blood.service';
import { UserService } from '../user.service';
import { Iblood } from '../Iblood';
import { Islot } from '../Islot';
import { DonateService } from '../donate.service';

@Component({
  selector: 'app-donate',
  templateUrl: './donate.component.html',
  styleUrls: ['./donate.component.css']
})
export class DonateComponent implements OnInit {

  constructor(private donateser:DonateService,private userser:UserService) { }
 flag:boolean=false
 user:Iblood
 slot:Islot=
{
  hospital:null,
    city:null,
    dateForDonating:null,
    timeForDonating:null
}
slots:Islot[]
success:boolean=false
msg:string
check:boolean=false
id:number
areas:string[];
  states:string[];
  ngOnInit() 
  {
    this.states=this.userser.states;
    this.user=
    {
      
      bloodGroup:null,
      state:null,
      area:null,
      pinCode:null,
      contact:null
      
    }
  }
  donateBlood(users:Iblood)
  {
    {{debugger}}
this.donateser.user=users
this.flag=true
  }
  bookSlot(slot:Islot)
  {
    {{debugger}}
    this.donateser.checkSlot(slot).subscribe(x=>{
      debugger
      this.slots=x as Islot[]
  
    if(this.slots.length==0)
    {
      this.id=this.userser.activeuser
      this.donateser.bookSlot(this.id,slot).subscribe(()=>
      {
        this.donateser.donate(this.userser.activeuser).subscribe()
      });
     this.check=false;
     this.success=true
    }
    else
    {
      this.check=true;
      this.msg="Sorry please try a different slot" 
      this.success=false
    }
  });
  }
  AssignArea(state:string)
  {
    if(state=="")
    {
      this.areas=[]
    }
    else if(state=='Kerala')
    {
      this.areas=this.userser.statesKerala;
    }
    else if(state=='TamilNadu')
    {
      this.areas=this.userser.statesTamil;
    }
  }
  maxDate:string='2020-11-11'
checkdate(invalDate:string):boolean{
  debugger
  if(invalDate==undefined)
  {
    return false;
  }
  else if(invalDate.localeCompare('2019-11-13')<1)
  {
    return true;
  }
  else if(this.maxDate.localeCompare(invalDate)<1)
  {
    return true;
  }
  else 
  {
    return false;
  }
}

}
