import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DirectdonateComponent } from './directdonate.component';

describe('DirectdonateComponent', () => {
  let component: DirectdonateComponent;
  let fixture: ComponentFixture<DirectdonateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DirectdonateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DirectdonateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
