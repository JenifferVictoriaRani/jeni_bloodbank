export interface IFaq
{
    id?:number
    userId?:number
    questions?:string
    answers?:string
}