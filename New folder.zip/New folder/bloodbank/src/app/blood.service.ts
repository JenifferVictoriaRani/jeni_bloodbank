import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Iblood } from './Iblood';
import { IbloodSearch } from './IbloodSearch';
import { Islot } from './Islot';

@Injectable({
  providedIn: 'root'
})
export class BloodService {

  constructor(private http: HttpClient) { }

  requirement():Observable<Iblood[]>
  {
    return this.http.get<Iblood[]>('http://localhost:54938/api/requirementDisplay')
  }

  availability():Observable<IbloodSearch[]>
  {
    return this.http.get<IbloodSearch[]>('http://localhost:58480/api/availability')
  }

  search(blooddetaild:IbloodSearch):Observable<IbloodSearch[]>
  {
    return this.http.get<IbloodSearch[]>('http://localhost:58480/api/search/'+blooddetaild.state+'/'+blooddetaild.area+'/'+blooddetaild.pinCode+'/'+blooddetaild.bloodGroup)
  }

  postReq(value:Iblood,UserId:number):Observable<{}>
  {
    return this.http.post('http://localhost:54938/api/requirementDisplay/'+UserId,value);
  }

 
}
