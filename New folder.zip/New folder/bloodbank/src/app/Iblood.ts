export interface Iblood
{
    id?:number
    userId?:number
    bloodGroup:string
    state:string
    area:string
    pinCode:number
    contact:number
    status?:string
    
}