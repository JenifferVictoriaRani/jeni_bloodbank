import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { IFaq } from '../IFaq';
import { FaqService } from '../faq.service';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { Iblood } from '../Iblood';
import { BloodService } from '../blood.service';
import { DonateComponent } from '../donate/donate.component';
import { DonateService } from '../donate.service';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['./adminhome.component.css']
})
export class AdminhomeComponent implements OnInit {

  constructor(private faqSer:FaqService,private userSer:UserService,private route:Router,private authguard:AuthService,private donateSer:DonateService) { }
  faq:IFaq[]
  blood:Iblood[]

  ngOnInit() {
    this.faqSer.faq().subscribe(x=>
      { {{debugger}}
        this.faq=x as IFaq[]
      }
    )
    this.donateSer.bloodDetails().subscribe(x=>{
      this.blood=x as Iblood[]
    })
  }
  logOut()
  {
    this.authguard.logOut();
    this.route.navigate(['home']);
  }
}
