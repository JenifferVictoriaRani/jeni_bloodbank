import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { IFaq } from '../IFaq';
import { FaqService } from '../faq.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private faqSer:FaqService,private userSer:UserService,private route:Router,private authguard:AuthService) { }
  faq:IFaq[]
  faq1:IFaq
  flag:boolean=false
  quesId:number
  Answer:string
  ngOnInit() {
   this.faq1=
   {
    id:null,
    userId:null,
    questions:null,
    answers:null
   }
    this.faqSer.adminFaq().subscribe(x=>
      { {{debugger}}
        this.faq=x as IFaq[]
      }
    )
    console.log(this.faq)
  }

  onSubmit(faq1:IFaq)
  {
    {{debugger}}
    this.faqSer.ansFaq(faq1.id,faq1.answers).subscribe(()=>{
     this.reload();
      }
    )
  }
  reload()
  {
  this.flag=true
      this.faqSer.adminFaq().subscribe((x:IFaq[])=>
        { {{debugger}}
          this.faq=x
         }
    )
    this.faq1=
   {
    id:null,
    userId:null,
    questions:null,
    answers:null
   }
    console.log(this.faq)
        }
        logOut()
    {
      this.authguard.logOut();
      this.route.navigate(['home']);
    }
}
