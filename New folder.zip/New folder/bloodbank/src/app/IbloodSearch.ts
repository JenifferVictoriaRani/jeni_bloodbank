export interface IbloodSearch
{
    userId:number
    firstName:string
    lastName: string
    bloodGroup:string
    state:string
    area:string
    pinCode:number
    contact:number
}