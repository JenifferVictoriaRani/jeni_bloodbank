import { Component, OnInit } from '@angular/core';
import { Iblood } from '../Iblood';
import { BloodService } from '../blood.service';
import { Observable } from 'rxjs';
import { UserService } from '../user.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userpage',
  templateUrl: './userpage.component.html',
  styleUrls: ['./userpage.component.css']
})
export class UserpageComponent implements OnInit {

  blooddetails:Observable<Iblood[]>
  constructor(private bloodSer:BloodService,private userser:UserService,private authguard:AuthService,private route:Router) { }

  ngOnInit() {
    this.blooddetails=this.bloodSer.requirement();
  }
  logOut()
  { debugger
    this.authguard.logOut();
    this.route.navigate(['home']);
  }
}
