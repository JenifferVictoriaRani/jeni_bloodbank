import { Component, OnInit } from '@angular/core';
import { BloodService } from '../blood.service';
import { Iblood } from '../Iblood';
import { UserService } from '../user.service';

@Component({
  selector: 'app-req-post',
  templateUrl: './req-post.component.html',
  styleUrls: ['./req-post.component.css']
})
export class ReqPostComponent implements OnInit {
flag:boolean=false

areas:string[];
  states:string[];
  user:Iblood=
  {
    
    bloodGroup:null,
    state:null,
    area:null,
    pinCode:null,
    contact:null
    
  }
  constructor(private bloodser:BloodService,private userser:UserService) { }

  ngOnInit() {
    this.states=this.userser.states;
  }
  postReq(user:Iblood)
  {
    {{debugger}}
    this.bloodser.postReq(user,this.userser.activeuser).subscribe();
    this.flag=true
  }
  AssignArea(state:string)
  {
    if(state=="")
    {
      this.areas=[]
    }
    else if(state=='Kerala')
    {
      this.areas=this.userser.statesKerala;
    }
    else if(state=='TamilNadu')
    {
      this.areas=this.userser.statesTamil;
    }
  }
}
