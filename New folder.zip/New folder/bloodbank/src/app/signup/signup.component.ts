import { Component, OnInit } from '@angular/core';
import { IUser } from '../IUser';
import { UserService } from '../user.service';
import { IUserreg } from '../IUserreg';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  msg:string;
  useremail:string;
  usercontact:bigint
  contacts:bigint[]
  emails:string[];
  areas:string[];
  states:string[];
 
  flag:boolean=false

  user:IUserreg=
  {
    firstName:null,
    lastName:null,
    age:null,
    gender:null,
    email:null,
    contact:null,
    pass:null,
    weight:null,
    state:null,
    area:null,
    pinCode:null,
    bloodGroup:null
  }
 
  users:IUser
  constructor(private userser:UserService) { }

  ngOnInit() {
    
    this.states=this.userser.states;
    this.userser.getEmails().subscribe(result=>{this.emails=result as string[],console.log(this.emails),this.getContacts()} )
  }
  getContacts()
 {
  this.userser.getContact().subscribe(result=>{this.contacts=result as bigint[],console.log(this.contacts)} )
 
 }

  register(user:IUserreg):void
  {
    {{debugger}}
    this.userser.addUser(user).subscribe(() => 
    { debugger
      // this.fetchId()
      this.userser.fetchIdOfUser().subscribe(result=>{this.users=result as IUser});
    this.flag=true
    }
    );
    
  }
  fetchId()
  {
    this.userser.fetchIdOfUser().subscribe(result=>{this.users=result as IUser});
    this.flag=true
  }
  check():boolean
  {
    {{debugger}}

    return true;
  }
  Unique(email:string):boolean
 {
   if(email==" ")
   {
     return false;
   }
   else
   {
   this.useremail=this.emails.find(x=>x==email);
   if(this.useremail==undefined)
   {
     return false;
   }
   else 
   {
     return true;
   }}
 }
  

 UniqueContact(contact:bigint):boolean
 {
   if(contact==undefined)
   {
     return false;
   }
   this.usercontact=this.contacts.find(x=>x==contact);
   if(this.usercontact==undefined)
   {
     return false;
   }
   else 
   {
     return true;
   }
 }
 AssignArea(state:string)
 {
   if(state=="")
   {
     this.areas=[]
   }
   else if(state=='Kerala')
   {
     this.areas=this.userser.statesKerala;
   }
   else if(state=='TamilNadu')
   {
     this.areas=this.userser.statesTamil;
   }
 }
 
  
}
