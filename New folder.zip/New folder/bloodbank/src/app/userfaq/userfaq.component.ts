import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { FaqService } from '../faq.service';
import { IFaq } from '../IFaq';


@Component({
  selector: 'app-userfaq',
  templateUrl: './userfaq.component.html',
  styleUrls: ['./userfaq.component.css']
})
export class UserfaqComponent implements OnInit {

  constructor(private userser:UserService,private faqSer:FaqService) { }
  faq:IFaq[]
  flag:boolean=false
faq1:IFaq
  ngOnInit() {
    this.faq1=
   {
    id:null,
    userId:null,
    questions:null,
    answers:null
   }
    this.flag=false
    this.faqSer.faq().subscribe(x=>
      { {{debugger}}
        this.faq=x as IFaq[]
      }
    )
  }

  onSubmit(faq1:IFaq)
  {
    {{debugger}}
    this.faqSer.quesPost(faq1.answers).subscribe(()=>
    {
      this.faqSer.faq().subscribe(x=>
        { {{debugger}}
          this.faq=x as IFaq[]
          this.flag=true
          
        }
      )
      this.faq1=
   {
    id:null,
    userId:null,
    questions:null,
    answers:null
   }
    })
  }

}
