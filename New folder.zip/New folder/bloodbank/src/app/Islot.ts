export interface Islot
{
    slotId?:number
    userId?:number
    hospital:string
    city:string
    dateForDonating:Date
    timeForDonating:string
    feedBack?:string
}