export interface IUserreg
{
    firstName:string
    lastName: string
    age:number
    gender:string
    email:string
    contact:number
    pass:string
    weight:number
    state:number
    area:string
    pinCode:number
    bloodGroup:string
}