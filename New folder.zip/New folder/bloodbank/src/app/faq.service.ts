import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IFaq } from './IFaq';
import { Observable } from 'rxjs';
import { IUser } from './IUser';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class FaqService {

  constructor(private http:HttpClient,private user:UserService) { }
 

  faq():Observable<IFaq[]>
  {
   
    return this.http.get<IFaq[]>('http://localhost:62985/api/faq')
  }

  adminFaq():Observable<IFaq[]>
  {
   
    return this.http.get<IFaq[]>('http://localhost:62985/api/adminFaq')
  }
  ansFaq(id:number,value:string):Observable<{}>
  { debugger
    return this.http.put('http://localhost:62985/api/adminFaq/'+id+'/'+value,{ headers: new HttpHeaders({ 'Content-Type': 'application/json'}) } )
  }
  quesPost(value:string):Observable<{}>
  {
    {{debugger}}
    return this.http.post<IFaq>('http://localhost:62985/api/faq/'+this.user.activeuser+'/'+value,{ headers: new HttpHeaders({ 'Content-Type': 'application/json'}) })
  }
}
