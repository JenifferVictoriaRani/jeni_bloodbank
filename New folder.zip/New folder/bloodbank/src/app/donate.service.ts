import { Injectable } from '@angular/core';
import { Iblood } from './Iblood';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Islot } from './Islot';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class DonateService {

  constructor(private http: HttpClient) { }
  user:Iblood

  bloodDetails()
  {
    return this.http.get('http://localhost:58932/api/donate')
  }
  checkSlot(slot:Islot):Observable<{}>
  {
    {{debugger}}
   
    return this.http.post<Islot[]>('http://localhost:58932/api/slot',slot)
   
  }
  bookSlot(id:number,value:Islot):Observable<{}>
  {
    return this.http.post('http://localhost:58932/api/slot/'+id,value)
  }
  donate(id:number):Observable<{}>
  {
    {{debugger}}
    return this.http.post('http://localhost:58932/api/donate/'+id,this.user)
  }
  updateBlood(id:number)
  {
    debugger
    return this.http.put('http://localhost:58932/api/donate/'+id,{ headers: new HttpHeaders({ 'Content-Type': 'application/json'}) } )
  }
}
