﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using bloodDonation.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace bloodDonation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class slotController : ControllerBase
    {
        bloodbankContext bb = new bloodbankContext();
        // GET: api/slot
        [HttpPost( Name = "GetSlot")]
        public IEnumerable<SlotDetails> Get([FromBody] SlotDetails slot)
        {
            
                return bb.SlotDetails.FromSql("checkSlot '"+slot.Hospital+"','"+slot.City+"','"+slot.DateForDonating+"','"+slot.TimeForDonating+"'").ToList();
            
            
        }

        // GET: api/slot/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/slot
        [HttpPost("{id}")]
        public void Post(int id,[FromBody]SlotDetails value)
        {
            bb.Database.ExecuteSqlCommand("bookSlot " + id + ",'" + value.Hospital + "','" + value.City + "','" + value.DateForDonating + "','" + value.TimeForDonating + "'");
        }

        // PUT: api/slot/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
