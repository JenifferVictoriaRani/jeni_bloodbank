﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using bloodDonation.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace bloodDonation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class donateController : ControllerBase
    {
        bloodbankContext bb = new bloodbankContext();
        // GET: api/donate
        [HttpGet(Name = "checkSlot")]
        public IEnumerable<BloodDetails> Get()
        {
            return bb.BloodDetails.ToList();
        }

        // GET: api/donate/5
        [HttpGet("{id}", Name = "Get1")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/donate
        [HttpPost("{id}")]
        public void Post(int id, [FromBody] BloodDetails value)
        {
            bb.Database.ExecuteSqlCommand("donateBlood " + id + ",'" + value.BloodGroup + "','" + value.State + "','" + value.Area + "'," + value.PinCode + "," + value.Contact);
        }

        // PUT: api/donate/5
        [HttpPut("{id}")]
        public void Put(int id)
        {
            bb.Database.ExecuteSqlCommand("updateDonation " + id);
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            BloodDetails b = bb.BloodDetails.Find(id);

            bb.BloodDetails.Remove(b);
            bb.SaveChanges();
            //bb.Database.ExecuteSqlCommand("deleteBlood " + id + ",'" + blood.BloodGroup + "','" + blood.State + "','" + blood.Area + "'," + blood.PinCode + "," + blood.Contact);
        }
    }
}
