alter proc registration(@FName varchar(50),@LName varchar(50),@age int,@gender varchar(6),@email varchar(50),@cont bigint,@pswd varchar(15),@wt int,@state varchar(30),@area varchar(30),@Pin_Code int,@Blood_Group varchar(15))
as
insert into user_details values (@FName,@LName,@age,@gender,@email,@cont,@pswd,@wt,@state,@area,@Pin_code,@Blood_Group,default)

create proc fetchId
as
select top 1 * from user_details order by UserId desc

CREATE proc loginuser(@uname varchar(50),@pswd varchar(50))
as
select * from user_details where UserId=@uname and Pass=@pswd

create proc requirement
as

 where status='no'

alter proc reqPost(@usid int,@blood varchar(15),@state varchar(30),@area varchar(30),@pin bigint,@cont bigint)
as

INSERT INTO [dbo].[blood_details]
           ([UserId]
           ,[Blood_Group]
           ,[State]
           ,[Area]
           ,[Pin_Code]
           ,[Contact]
           ,[Status])
     VALUES
           (@usid,@blood,@state,@area,@pin,@cont,'no')

alter proc searchAva(@state varchar(30),@area varchar(30),@pin bigint,@blood varchar(15))
as
select * from Blood_details where (State=@state and Area=@area and Pin_Code=@pin and Blood_Group=@blood and status='yes')


create proc selectuser
as
SELECT [UserId]
      ,[First_Name]
      ,[Last_Name]
      ,[Age]
      ,[Gender]
      ,[Email]
      ,[Contact]
      ,[Pass]
      ,[Weight]
      ,[State]
      ,[Area]
      ,[Pin_Code]
      ,[Blood_Group]
      ,[Role]
  FROM [dbo].[user_details]

create proc availability
as
select * from Blood_details where status='yes'

execute availability

 select * from sysobjects where type='p' and category=0

sp_helptext selectuser

delete from user_details where Age=11

alter proc deletereq (@bg varchar(15),@state varchar(30),@area varchar(30),@pin int)
as 
delete from blood_details where Blood_Group=@bg and State=@state and area=@area and Pin_Code=@pin and status='no'

alter proc donateBlood (@id int,@bg varchar(15),@st varchar(30),@ar varchar(30),@pin int,@cont bigint)
as
insert into blood_details values (@id,@bg,@st,@ar,@pin,@cont,'yes')

create proc slot
as
select * from slot_details

create proc checkSlot(@hos varchar(30),@city varchar(30),@date date,@time varchar(20))
as
select * from slot_details where Hospital=@hos and City=@city and Date_for_donating=@date and Time_for_donating=@time

create proc bookSlot(@id int, @hos varchar(30),@city varchar(30),@date date,@time varchar(20))
as
insert into slot_details values (@id, @hos,@city,@date,@time,null)

delete from blood_details where UserId=1013

checkSlot 'MVR','Sholinganallur','2019/11/08','9am to 9.30am'

alter proc deleteBlood(@UserId int,@bg varchar(15),@state varchar(30),@area varchar(30),@pin int,@con bigint)
as
delete from blood_details where UserId=@UserId and Blood_Group=@bg and State=@state and Area=@area and Pin_Code=@pin and Contact=@con and status='no'

select * from blood_details where Status='no'

create proc selectFaq
as
select * from faq

create proc quesPost(@userId int,@ques varchar(500))
as
insert into faq values (@userId,@ques,'null')

execute quesPost 1003,'vvv'

execute quesPost 1013,'Within how many days can I donate again?' 

create proc quesAns(@id int,@ans varchar(500))
as
update faq set Answers=@ans where Id=@id

alter proc dispQues
as
select * from faq where Answers='not yet answered'

execute dispQues

alter proc ques(@id int,@ques varchar(500))
as
insert into faq values(@id,@ques,'not yet answered')

execute ques 1008,'ccvv'

Within how many days can I donate again? can a drunken person donate blood I am below 20. Can i donate


delete from faq where Answers='cccc'

alter proc updateDonation(@Id int)
as
update blood_details
set
Status='done'
 where Id=@Id 

 execute updateDonation 1015
