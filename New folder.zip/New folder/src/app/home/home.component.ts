import { Component, OnInit } from '@angular/core';
import { IUser } from '../IUser';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { Observable } from 'rxjs';
import { BloodService } from '../blood.service';
import { Iblood } from '../Iblood';
import { UserService } from '../user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  user:IUser
  users:Observable<IUser>
  constructor(private userService:UserService,private router: Router,private authService:AuthService) { }
  msg:string
  flag:boolean

  ngOnInit() {
  }
  onSubmit(userId:number,pass:string)
  {
    
    this.userService.getUser(userId,pass).subscribe((x:IUser)=>{
      debugger
      this.user=x ;

    
    //console.log(this.user.role)
if(this.user==null)
{
this.flag=false
this.msg="Incorrect username or password"
}
else
{
  this.flag=true
  this.msg=""
}
  
console.log(this.user);
if( this.user.role=="Admin")
{
  this.userService.activeuser=this.user.userId;
  this.userService.activeusername=this.user.firstName
       this.authService.login();
      console.log(this.user.role)
     this.router.navigate(['/adminhome']);
     
     }
     else if(this.user.role=="User")
       {
        this.userService.activeuser=this.user.userId;
        this.userService.activeusername=this.user.firstName
       this.authService.login();
       console.log(this.user.role)
      this.router.navigate(['/userpage']);
      
       }
       
  }
    );
  }
}
