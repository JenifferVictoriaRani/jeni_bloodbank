import { Injectable } from '@angular/core';
import { IUser } from './IUser';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import {Observable, ObjectUnsubscribedError} from 'rxjs';
import { IUserreg } from './IUserreg';
import { AuthguardService } from './authguard.service';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http: HttpClient,public authguard:AuthService,public route:Router) { }
  readonly url='http://localhost:52337/api/login'
  users:IUser[]=[]
  activeuser:number=null
  activeusername:string;
  states:string[]=['Kerala','TamilNadu'];
  statesKerala:string[]=['cochin','Kollam'];
  statesTamil:string[]=['Chennai','Pondy','Trichy','cuddalore'];


   addUser(value:IUserreg):Observable<{}>
    {
      {{debugger}}
      
      return this.http.post('http://localhost:52337/api/register',value);
      //return this.http.put(this.rootURL+'/'+item.me_id.toString(), item,{
        //headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
  getUser(UserId:number,pass:string):Observable<IUser>
    {
      return this.http.get<IUser>(this.url+'/'+UserId+'/'+pass);
    }
    fetchIdOfUser():Observable<IUser>
    {
      return this.http.get<IUser>('http://localhost:52337/api/register')
    }
    getContact()
{
  return this.http.get('http://localhost:52337/api/login/GetContact');
  
}

 getEmails()
 {
   return this.http.get('http://localhost:52337/api/login/GetEmails');
 }

    logOut()
    {
      this.authguard.logOut();
      this.route.navigate(['home']);
    }
}
