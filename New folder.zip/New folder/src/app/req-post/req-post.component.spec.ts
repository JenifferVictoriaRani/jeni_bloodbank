import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReqPostComponent } from './req-post.component';

describe('ReqPostComponent', () => {
  let component: ReqPostComponent;
  let fixture: ComponentFixture<ReqPostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReqPostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReqPostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
