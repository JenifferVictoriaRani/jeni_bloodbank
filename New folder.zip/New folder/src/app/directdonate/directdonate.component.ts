import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { ActivatedRoute,Router } from '@angular/router';
import { DonateService } from '../donate.service';
import { Islot } from '../Islot';
import { UserService } from '../user.service';

@Component({
  selector: 'app-directdonate',
  templateUrl: './directdonate.component.html',
  styleUrls: ['./directdonate.component.css']
})
export class DirectdonateComponent implements OnInit {

  constructor(private authService:AuthService,private userser:UserService, private route:ActivatedRoute,private donateser:DonateService) { }
  slots:Islot[]
  id:number
  msg:string
  flag:boolean=false
  check:boolean=false
  mid:number
  slot:Islot=
  {
    hospital:null,
      city:null,
      dateForDonating:null,
      timeForDonating:null
  }
  
  ngOnInit() {
    //const mid=+this.route.s
   this.mid = +this.route.snapshot.paramMap.get('id');
  }
  bookSlot(slot)
  {
    this.flag=true
    {{debugger}}
    this.donateser.checkSlot(slot).subscribe(x=>{
      debugger
      this.slots=x as Islot[]
  
    if(this.slots.length==0)
    {
      this.id=this.userser.activeuser
      this.donateser.bookSlot(this.id,slot).subscribe(()=>
      {
        debugger
        this.donateser.updateBlood(this.mid).subscribe()
      });
   this.check=false
   this.msg="Slot booked successfully. You are going to save a life"
    }
    else
    {
      
      this.msg="Sorry please try a different slot" 
      this.check=true
    }
  });
  }
  maxDate:string='2020-11-11'
  checkdate(invalDate:string):boolean{
    debugger
    if(invalDate==undefined)
    {
      return false;
    }
    else if(invalDate.localeCompare('2019-11-13')<1)
    {
      return true;
    }
    else if(this.maxDate.localeCompare(invalDate)<1)
    {
      return true;
    }
    else 
    {
      return false;
    }
  }
  
}
