import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { HomeComponent } from './home/home.component';
import { SearchComponent } from './search/search.component';
import { UserpageComponent } from './userpage/userpage.component';
import { AuthguardService } from './authguard.service';
import { ReqPostComponent } from './req-post/req-post.component';
import { DonateComponent } from './donate/donate.component';
import { DirectdonateComponent } from './directdonate/directdonate.component';
import { AdminComponent } from './admin/admin.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { UserfaqComponent } from './userfaq/userfaq.component';


const routes: Routes = [
 
  {
    path:'signup',
    component:SignupComponent
  },
  {
    path:'home',
    component:HomeComponent
  },
  {
    path:'search',
    component:SearchComponent,canActivate: [AuthguardService]
  },
  {
    path:'userpage',
    component:UserpageComponent,canActivate: [AuthguardService]
  },
  {
    path:'reqPost',
    component:ReqPostComponent,canActivate: [AuthguardService]
  },
  {
    path:'donate',
    component:DonateComponent,canActivate: [AuthguardService]
  },
  {
    path:'directDonate/:id',
    component:DirectdonateComponent,canActivate: [AuthguardService]
  },
  {
    path:'admin',
    component:AdminComponent,canActivate: [AuthguardService]
  },
  {
    path:'adminhome',
    component:AdminhomeComponent,canActivate: [AuthguardService]
  },
  {
    path:'faq',
    component:UserfaqComponent,canActivate: [AuthguardService]
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
