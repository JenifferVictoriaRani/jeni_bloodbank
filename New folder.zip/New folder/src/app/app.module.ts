import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignupComponent } from './signup/signup.component';
import { HttpClient,HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { SearchComponent } from './search/search.component';
import { UserpageComponent } from './userpage/userpage.component';
import { ReqPostComponent } from './req-post/req-post.component';
import { DonateComponent } from './donate/donate.component';
import { DirectdonateComponent } from './directdonate/directdonate.component';
import { AdminComponent } from './admin/admin.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { UserfaqComponent } from './userfaq/userfaq.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    HomeComponent,
    SearchComponent,
    UserpageComponent,
    ReqPostComponent,
    DonateComponent,
    DirectdonateComponent,
    AdminComponent,
    AdminhomeComponent,
    UserfaqComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    BsDatepickerModule.forRoot(),
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
