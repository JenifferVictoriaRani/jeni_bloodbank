import { Component, OnInit } from '@angular/core';
import { IbloodSearch } from '../IbloodSearch';
import { Observable } from 'rxjs';
import { BloodService } from '../blood.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  areas:string[];
  states:string[];
  constructor(private bloodSer:BloodService,private userser:UserService) { }
  available:IbloodSearch[]=null
  filteredAvailability:IbloodSearch[]=null
  blooddetails:IbloodSearch=
  {
    userId:null,
    firstName:null,
    lastName:null,
    bloodGroup:null,
    state:null,
    area:null,
    pinCode:null,
    contact:null
  }
  flag:boolean
  check:boolean
  msg:string
  ngOnInit() {
    this.states=this.userser.states;
    this.bloodSer.availability().subscribe(x=>{this.available=x as IbloodSearch[]})
    this.filteredAvailability=this.available
    this.flag=false
    this.check=false
    
  }
  onSubmit(blooddetails:IbloodSearch)
  {
    {{debugger}}
    
    
      this.bloodSer.search(blooddetails).subscribe(
        (x:IbloodSearch[])=>{
      debugger
        this.filteredAvailability=x 
      
      if(this.filteredAvailability.length==0)
      {
        this.flag=true
        this.msg="No Availability.Post your requirement"
        this.check=false
      }
      else{
        this.msg=""
        this.flag=false
        this.check=true
      }
    
  }
      )
  // check():boolean
  // {
  //   if(this.filteredAvailability==null)
  //   {
  //     return true;
  //   }
  //   else{
  //     return false;
  //   }
  // }
}
AssignArea(state:string)
{
  if(state=="")
  {
    this.areas=[]
  }
  else if(state=='Kerala')
  {
    this.areas=this.userser.statesKerala;
  }
  else if(state=='TamilNadu')
  {
    this.areas=this.userser.statesTamil;
  }
}
}
